define(['./dist/airflowButton'], (supernova) => supernova);
